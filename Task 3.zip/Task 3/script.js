function validateForm(event) {
    event.preventDefault();
  
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;
  
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
    if (name.trim() === "" || email.trim() === "" || message.trim() === "") {
      displayErrorMessage("All fields are required.");
    } else if (!emailRegex.test(email)) {
      displayErrorMessage("Please enter a valid email address.");
    } else {
      displaySuccessMessage();
    }
  }
  
  function displaySuccessMessage() {
    hideErrorMessage();
    const successMessage = document.getElementById("successMessage");
    successMessage.classList.remove("hidden");
  }
  
  function displayErrorMessage(message) {
    const errorMessage = document.getElementById("errorMessage");
    errorMessage.textContent = message;
    errorMessage.classList.remove("hidden");
  }
  
  function hideErrorMessage() {
    const errorMessage = document.getElementById("errorMessage");
    errorMessage.textContent = "";
    errorMessage.classList.add("hidden");
  }
  
  document.addEventListener("DOMContentLoaded", function () {
    const contactForm = document.getElementById("contactForm");
    contactForm.addEventListener("submit", validateForm);
  });
  