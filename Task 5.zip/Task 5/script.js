let slideIndex = 0;
const slides = document.getElementsByClassName("carousel-slide");

// Function to show slides
function showSlides() {
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    // Loop back to the first slide if at the end
    slideIndex = (slideIndex + 1) % slides.length;

    slides[slideIndex].style.display = "block";
}

// Function to navigate to the previous or next slide
function plusSlides(n) {
    slideIndex += n;
    if (slideIndex >= slides.length) {
        slideIndex = 0;
    } else if (slideIndex < 0) {
        slideIndex = slides.length - 1;
    }
    showSlides();
}

// Auto-play the carousel every 3 seconds
setInterval(showSlides, 3000);

// Show the first slide when the page loads
showSlides();
