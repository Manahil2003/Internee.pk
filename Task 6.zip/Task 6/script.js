document.addEventListener("DOMContentLoaded", function() {
    // Simulate asynchronous loading of an additional script
    const additionalScript = document.createElement('script');
    additionalScript.src = 'additional-script.js';
    additionalScript.defer = true;
    document.head.appendChild(additionalScript);

    // Simulate lazy loading of additional content
    const boxes = document.querySelectorAll('.box[data-async="true"]');
    boxes.forEach(box => {
        const dataType = box.getAttribute('data-type');
        const dataSrc = box.getAttribute('data-src');

        if (dataType === 'html') {
            fetch(dataSrc)
                .then(response => response.text())
                .then(html => {
                    box.innerHTML = html;
                });
        }
    });
});
